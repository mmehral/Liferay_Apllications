package com.liferay.training.space.gradebook.portlet;

public class GradebookPortletKeys {

	/*public static final String PORTLET_NAME =
		"com_liferay_training_space_gradebook_portlet_GradebookPortlet";*/
}
