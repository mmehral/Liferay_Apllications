package com.liferay.training.parts.portlet.command;

import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.training.parts.model.Manufacturer;
import com.liferay.training.parts.service.ManufacturerLocalService;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(
		immediate = true,
		property = {
	        "javax.portlet.name=comliferaytrainingpartsportletManufacturerPortlet",
	        "mvc.command.name=/parts-inventory/manufacturer/add"
	    },
	    service = MVCActionCommand.class
	)
public class AddManufacturerMVCActionCommand extends BaseMVCActionCommand{

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		// TODO Auto-generated method stub

		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest
				.getAttribute(WebKeys.THEME_DISPLAY);
		long groupId = themeDisplay.getScopeGroupId();
		
		/*
	String name  =	ParamUtil.getString(actionRequest,"name");
	String emailAddress = ParamUtil.getString(actionRequest, "emailAddress");	
	String website = ParamUtil.getString(actionRequest, "website");
	Long phoneNumber = ParamUtil.getLong(actionRequest, "phoneNumber");*/
		Manufacturer manufacturer = manufacturerLocalService.createManufacturer(0);

		manufacturer.setManufacturerId(ParamUtil.getLong(actionRequest, "manufacturerId"));
		manufacturer.setName(ParamUtil.getString(actionRequest, "name"));
		manufacturer.setEmailAddress(ParamUtil.getString(actionRequest, "emailAddress"));
		manufacturer.setWebsite(ParamUtil.getString(actionRequest, "website"));
		manufacturer.setPhoneNumber(ParamUtil.getString(actionRequest, "phoneNumber"));
		manufacturer.setCompanyId(themeDisplay.getCompanyId());
		manufacturer.setGroupId(themeDisplay.getScopeGroupId());
		manufacturer.setUserId(themeDisplay.getUserId());

		manufacturerLocalService.addManufacturer(manufacturer);
		sendRedirect(actionRequest, actionResponse);
	}
	
	
	@Reference(unbind="-")
	protected ManufacturerLocalService manufacturerLocalService;
	
	
	
	
	
}
