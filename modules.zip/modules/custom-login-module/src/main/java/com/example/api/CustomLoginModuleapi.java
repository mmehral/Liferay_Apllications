package com.example.api;

public interface CustomLoginModuleapi {
}