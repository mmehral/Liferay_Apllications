package com.liferay.training.space.gradebook.workflow;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.security.permission.ResourceActionsUtil;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.workflow.BaseWorkflowHandler;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.liferay.portal.kernel.workflow.WorkflowHandler;
import com.liferay.training.space.gradebook.model.Assignment;
import com.liferay.training.space.gradebook.service.AssignmentLocalService;

import java.io.Serializable;
import java.util.Locale;
import java.util.Map;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(
		property={"model.class.name=com.liferay.training.space.gradebook.model.Assignment",	
		},
		service=WorkflowHandler.class
		
		)
public class AssignmentWorkflowHandler extends BaseWorkflowHandler<Assignment>{
	{
		
		
		
	}

	@Override
	public String getClassName() {
		// TODO Auto-generated method stub
		return Assignment.class.getName();
	}

	@Override
	public String getType(Locale locale) {
		// TODO Auto-generated method stub
		return ResourceActionsUtil.getModelResource(locale,getClassName());
	}

	@Override
	public Assignment updateStatus(int status, Map<String, Serializable> workflowContext) throws PortalException {
		// TODO Auto-generated method stub
		
		 long userId = GetterUtil.getLong(
			        (String)workflowContext.get(WorkflowConstants.CONTEXT_USER_ID));
			    long classPK = GetterUtil.getLong(
			        (String)workflowContext.get(
			            WorkflowConstants.CONTEXT_ENTRY_CLASS_PK));

			    ServiceContext serviceContext = (ServiceContext)workflowContext.get("serviceContext");
			    	
			//return   _assignmentLocalService.updateStatus(userId, assignmentId, status, serviceContext)
		return _assignmentLocalService.updateStatus(userId,classPK,status,serviceContext);
	}
	
	@Reference
	private AssignmentLocalService _assignmentLocalService;

}
